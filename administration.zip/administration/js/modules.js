function getId(el){
		return document.getElementById(el);
	}