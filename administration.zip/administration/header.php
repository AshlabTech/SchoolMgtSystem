<nav class="navbar" style="margin-bottom:0">
							  <div class="container-fluid">
								<div class="navbar-header">
								  <a class="navbar-brand" href="#">
									PEACE GROUP OF SCHOOLS MOKWA, NIGER STATE. <br>
										<center><span style="color:red;font-family:Arial;font-size:14px;">Motto : Industrious and Fruitfulness.</span></center>
								  </a>
								</div>
								 <!-- Collect the nav links, forms, and other content for toggling -->
												<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
											
													<img src="images/logo_pss.png" style="width:80px;height:90px;margin-top:10px">
								
									</div>
							  </div>
							</nav>
								<!-- BEginning of menusystem -->
						<div class="row"  style="margin:0;padding:0;height:30px;">
							<div class="col-lg-12" id="menusystem_wrap" >
								
							</div>
						</div>
							
							<!-- end of menusystem -->