

<!DOCTYPE html>
<html>
	<head>
		<title>Peace Group of Schs. | MOKWA </title>
			
			<link rel="shortcut icon" href="../images/e_portal.png">
		
		<link rel="stylesheet" href="../css/font-awesome-4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<link rel="stylesheet" href="../css/bootstrap-theme.css">
		<link rel="stylesheet" href="../css/bootstrap-theme.min.css">
		<link rel="stylesheet" href="../css/styles.css">
		
				
				<!-- inlcude all javascript files -->
				<script type="text/javascript" src="../js/jquery-1.10.2.js"></script>	
				<script type="text/javascript" src="staff/js/staff_scripts.js"></script>


		
		<style>
			
		</style>
	</head>
<body>
	<!-- body container-->
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-1"></div>
				<div class="col-lg-10"  id="whole_body" style="overflow-x:hidden">
		
					<!--	header -->
					<?php include_once('header.php'); ?>
				<!--	end header -->
					
								<!-- end of header -->	
								
								<!-- beginning of login wrap -->	
									<div class="row" >
										
										<div class="col-lg-12 text-center">
												<div class="form-horizontal" id="login_container">
												  <div class="form-group">
													<label for="admin_id_input" class="col-sm-3 text-left control-label">Id :</label>
													<div class="col-sm-9">
													  <input type="text" class="form-control" id="staff_id" placeholder="Staff Id or Username">
													</div>
												  </div>
												  <div class="form-group">
													<label for="admin_pass_input" class="col-sm-3 text-left control-label">Password :</label>
													<div class="col-sm-9">
													  <input type="password" class="form-control" id="staff_pass" placeholder="Password">
													</div>
												  </div>
												
												  <div class="form-group">
													<div class="col-sm-12 text-center">
													  <button type="submit" class="btn btn-primary" onclick="staff_login()">Sign in</button><br><br>
													  <div id="login_status"> </div>
													</div>
												  </div>
												</div>
										</div>
									
									</div>
								<!-- end of login wrap  -->	
								
								<!-- -->
								<div class="row" style="margin:0px -30px">
									<div class="col-lg-12">
										<div id="" style="background-color:#818ea7;padding:5px;color:#fff">
											<h1> footer</h1>
										</div>
									</div>
								</div>
							<!-- -->
							
				</div>
				<div class="col-lg-1"></div>
			</div>
		</div>
	<!-- body container-->
	
	<!-- body container-->
	
</body>
</html>
