<div class="row" >
<div class="col-lg-12">
	<div class="panel"  style="padding:0;">
	  <div class="panel-heading" id="staff_alerts" style="background-color:#4188C4;color:#fff;font-weight:bolder"><span class="fa fa-bullhorn" style="margin-right:20px"></span> ALERTS</div>
	  <div class="panel-body" id="staff_alerts" style="padding:0">
			<?php include_once('../php/notifications.php');?>
	  </div>
	</div>
</div>
</div>
<div class="row">
	<div class="col-lg-6">
			<div class="panel " style="padding:0;">
		  <div class="panel-heading" style="background-color:orange;color:#000;font-weight:bolder"><span class="fa fa-calendar" style="margin-right:20px"></span> School Updates</div>
		  <div class="panel-body" style="padding:0;height:200px;">
						
						
						
						 
		  </div>
		</div>
	</div>
	<div class="col-lg-6">
		<div class="panel " style="padding:0;">
		  <div class="panel-heading" style="background-color:#4188C4;color:#fff;font-weight:bolder"><span class="fa fa-calendar" style="margin-right:20px"></span> Upcoming Events this Month</div>
		  <div class="panel-body" style="padding:0">
				<?php include_once('../php/notifications.php');?>
		  </div>
		</div>
	</div>
</div>