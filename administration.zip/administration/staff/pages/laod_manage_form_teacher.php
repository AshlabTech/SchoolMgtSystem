
<div id="iframeLoader">
    <center><img src="../../images/ajax-loader.gif" ><br> please, wait...<c/enter>
</div>
<iframe src="../staff/pages/form_teacher_page_for_iframe.php" style="width: 100% !important; min-height: 600px;border: none; overflow: scroll;"></iframe>