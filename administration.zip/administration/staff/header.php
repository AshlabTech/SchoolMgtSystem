	<!-- beginning of header -->
<!-- BEginning of nav -->
				<nav class="navbar " style='border-radius:0px;background-color:#4188C4;border:none;margin:0'>
				  <div class="container-fluid">
					<div class="navbar-header">
					  <a class="navbar-brand" href="#" style="color:#fff">
						<?php echo $school_abbr; ?>
					  </a>
					</div>
					 <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
       
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Logout</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Profile <span class="caret"></span></a>
          <div class="dropdown-menu" role="menu">
           
          </div>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
				  </div>
				</nav>
					
			<!-- end of nav -->
		
			<!-- body container-->
	
		<div class="row" style="margin:0">
					<div class="col-md-12" style="padding:0">
					
							<ul class="nav nav-tabs" role="tablist" id="myTab" style="background-color:#f1f1f1;height:20px">
							
							</ul>
					</div>
		</div>