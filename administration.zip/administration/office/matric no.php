<?php


?>

<form method="POST" action="#">
Matric Number:
<input="text" name="matric_no"><br><br>
<input="submit" name="matric_no" value="submit"><br><br>
</form>