<div id="iframeLoader">
    <center><img src="../../images/ajax-loader.gif" ><br> please, wait...<c/enter>
</div>
<iframe id="comulative_iframex" style="width: 100%; height:84vh;" src="cummulative_result_frame.php" frameborder="0">
</iframe>
