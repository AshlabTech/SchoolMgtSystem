<div class="panel panel-primary" style="margin:0;border-radius:0">
  <div class="panel-heading" style="border-radius:0">Add System USER<span style="float:right;cursor:pointer" title="close"class="glyphicon glyphicon-remove" onclick="myAlert.close()"></span></div>
  <div class="panel-body">
					<div class="form-inline">
					<div class="form-group">
							<label class="" for="staff_id">Staff ID</label><br>
							<input type="text" class="form-control" id="staff_login_id" placeholder="Staff ID">
					 </div>
					<div class="form-group">
						  <label class="" for="staff_id"></label><br>
						  <button type="button" class="btn btn-primary" title="add system user" onclick="add_system_user()">Add User</button>
					</div>
				</div>
  </div>
</div>