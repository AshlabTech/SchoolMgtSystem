
	<h4><button class="btn btn-primary" name="info" onclick="load_all_student()"style="margin-right:20px;">Back</button>New Student Registration Form </h4>
		<div id="add_new_staff_form">
			
			<div class="row" id="phase1" style="display:block">
				<div class="col-lg-12">
					<br><br>
					<iframe src="uploadStudent.php" style="width: 100%; height: 500px;border: none;"></iframe>
					
					
					 <div id="add_new_student_feedback"></div>
				</div>
				<div class="col-lg-6">			
					
					  
				</div>
			</div>						
		
		</div>
	
