<?php 
			include_once('../php/connection.php');
?>
	<h4><i class="menu-icon fa fa-desktop"></i> Manage Result code</h4>
		<div class="breadcrumb ace-save-state" id="breadcrumbs" style="margin:0">
			<div  class="" id="sub_nav" >
				<i class="ace-icon fa fa-cog home-icon"></i><a href="#">   <b>Code Checker</b></a>
				
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">			
			<hr/>					 
			<iframe src="codegenerator.php" style="width: 100%; height: 560px; border: none;"></iframe>											 
		</div>
	</div>