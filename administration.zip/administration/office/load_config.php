


<iframe src="configuration.php" style="width: 100%; height: 600px; border: none; overflow: auto;"></iframe>