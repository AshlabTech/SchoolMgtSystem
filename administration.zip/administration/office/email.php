<?php
if(isset($_POST['email'])){
	$@yahoo.com=$_POST['@yahoo.com'];
	$@gmail.com=$_POST['@gmail.com'];
	$@naija.com=$_POST['@naija.com'];
	
	if
}

?>
<form method="post" action="#">
Email:
<input type="text" name="email"><br><br>
<input type="submit" name="email" value="submit"><br><br>
</form>