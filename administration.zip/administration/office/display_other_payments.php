
<center>
    <h4><img src='../../images/ajax-loader.gif' style="width:90px; height:90px;" id="iframeloader"></h4>
</center>
<iframe style="width: 100%; height:80vh;" src="display_other_payment_frame.php?session_id=<?php echo $_POST['session_id'];?>" frameborder="0">
</iframe>
