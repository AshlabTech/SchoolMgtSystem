<?php
	$student_info_id = $_POST['token'];
	include_once('connection.php');
	include_once('student_data.php');
	echo $user_pic;
?>