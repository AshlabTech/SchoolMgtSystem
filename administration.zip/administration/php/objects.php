<?php
include_once('Models/User.php');
include_once('Models/Student.php');
include_once('Models/Staff.php');
include_once('Models/Session.php');
include_once('Models/Class.php');
include_once('Models/Section.php');
include_once('Models/Term.php');
include_once('Models/Mark.php');
include_once('Models/Subject.php');
include_once('Models/Result.php');

    $user_obj = new User;
    $student_obj = new Student;
    $staff_obj = new Staff;
    $session_obj = new Session;
    $class_obj = new Class_;
    $section_obj = new Section;
    $term_obj = new Term;
    $mark_obj = new Mark;
    $subject_obj = new Subject;
    $result_obj = new Result;

?>