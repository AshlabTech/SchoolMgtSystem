<?php
	
	echo @date('y').@date('m').@date('d').(@date('h')-1).@date('i').@date('s');


?>